#ifndef interfazUsuarioh
#define interfazUsuarioh


void inicInterfazUsuario();
void inicInterfazUsuario2();
void inicInterfazUsuario3();
void inicInterfazUsuario4();
void gestionMenuDatos();
int menuDatos();
void gestionMenuPrincipal();
int menuPrincipal();
#endif // interfazUsuario.h
